#! /bin/bash
g++ -c 1.cpp -o 1.o

g++ 1.o -o Main -lm
