#! /bin/bash
g++ -c 3.cpp -o 3.o
g++ 3.o -o Main